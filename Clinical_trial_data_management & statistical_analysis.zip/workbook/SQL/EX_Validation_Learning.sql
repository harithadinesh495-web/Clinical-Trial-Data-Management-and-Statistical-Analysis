/* =========================================================
   Clinical Trial Data Validation
   Dataset: EX
   Purpose: Exposure Data Validation
   ========================================================= */
/* To check the structure of table */
SELECT * 
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME='EX';

SELECT DATA_TYPE,
	   COLUMN_NAME,
	   CHARACTER_MAXIMUM_LENGTH
	   FROM INFORMATION_SCHEMA.COLUMNS
	   WHERE TABLE_NAME='EX';

/* To check the count of records */
SELECT COUNT(*) AS TOTAL_RECORDS
FROM EX;

/* To check the duplicates */
SELECT SUBJID,EXSTDTC,EXTRT, COUNT(*) AS N 
FROM EX
GROUP BY SUBJID,EXSTDTC,EXTRT
HAVING COUNT(*) >1;

/* To check the missing values */
SELECT * 
FROM EX
WHERE SUBJID IS NULL 
OR SUBJID IS NULL 
OR EXSEQ IS NULL
OR VISIT IS NULL
OR VISITNUM IS NULL
OR EXTRT IS NULL
OR EXDOSE IS NULL
OR EXDOSU IS NULL
OR EXROUTE IS NULL
OR EXFREQ IS NULL
OR EXSTDTC IS NULL;

/* To check the SUBJID validity */
SELECT EX.SUBJID
FROM EX
LEFT JOIN DM 
ON EX.SUBJID=DM.SUBJID
WHERE DM.SUBJID IS NULL;

/* To check treatment consistency with DM */
SELECT EX.EXTRT,DM.ARM
FROM EX
LEFT JOIN DM
ON EX.SUBJID=DM.SUBJID
WHERE EX.EXTRT<>DM.ARM OR DM.SUBJID IS NULL;

/* To check treatment terminology */
SELECT EXTRT
FROM EX 
WHERE EXTRT NOT IN ('Placebo','Investigational Drug')
GROUP BY EXTRT;

/* To check dose numeric validity */
SELECT COUNT(*) AS N
FROM EX 
GROUP BY EXDOSE;

/* To check dose unit consistency */
SELECT EXDOSU, COUNT(*) AS N
FROM EX
GROUP BY EXDOSU;

/* To check dose route consisitency */
SELECT EXROUTE, COUNT(*) AS N 
FROM EX
GROUP BY EXROUTE;

/* To check EXSTDTC date validity */
SELECT EXSTDTC,COUNT(*) AS N
FROM EX 
GROUP BY EXSTDTC;

/* To check visit / exposure consistency */
SELECT VISIT,VISITNUM, COUNT(*) AS N
FROM EX 
GROUP BY VISIT,VISITNUM
ORDER BY VISITNUM ASC;

/* To check treatment distribution */
SELECT EXTRT, COUNT(*) 
FROM EX
GROUP BY EXTRT;

/* To check DM–EX subject/treatment linkage */
SELECT DM.SUBJID,EX.SUBJID,EX.EXTRT,DM.ARM,COUNT(*) AS N
FROM EX
LEFT JOIN DM 
ON DM.SUBJID=EX.SUBJID
GROUP BY EX.EXTRT,DM.ARM,DM.SUBJID,EX.SUBJID;