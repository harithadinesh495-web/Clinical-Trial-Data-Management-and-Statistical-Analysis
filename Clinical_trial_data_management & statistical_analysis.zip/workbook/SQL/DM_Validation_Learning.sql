/* =========================================================
   Clinical Trial Data Validation
   Dataset: DM
   Purpose: Subject-Level Data Validation
   ========================================================= */
-- Check number of records per subject
USE T2_DM_Clinical_Trial;
GO

CREATE TABLE DM (
    STUDYID VARCHAR(30),
    SUBJID VARCHAR(20) PRIMARY KEY,
    AGE INT,
    SEX VARCHAR(10),
    RACE VARCHAR(50),
    ARM VARCHAR(50),
    COUNTRY VARCHAR(30),
    DMDTC DATE
);
GO

/* To check the structure of database*/
SELECT *
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME = 'DM';

SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'DM'
ORDER BY ORDINAL_POSITION;

SELECT COUNT(*) AS TOTAL_RECORDS
FROM DM;

/* To check the count of record */
SELECT SUBJID, COUNT(*)
FROM DM
GROUP BY SUBJID;

/* To check the null records */
SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE SUBJID IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE STUDYID IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE DMDTC IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE ARM IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE STUDYID IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE AGE IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE SEX IS NULL;

SELECT COUNT(*) AS NULL_RECORD
FROM DM
WHERE RACE IS NULL;

/* To check the duplicates for SUBJID IN DM */
SELECT SUBJID, COUNT(*) AS TOTAL_COUNT
FROM DM
GROUP BY SUBJID 
HAVING COUNT(*)>1;

/* To check missing values */
SELECT *
FROM DM 
WHERE STUDYID IS NULL;

SELECT *
FROM DM 
WHERE SUBJID IS NULL;

SELECT *
FROM DM 
WHERE AGE IS NULL;

SELECT *
FROM DM 
WHERE SEX IS NULL;

SELECT *
FROM DM 
WHERE RACE IS NULL;

SELECT *
FROM DM 
WHERE ARM IS NULL;

SELECT *
FROM DM 
WHERE COUNTRY IS NULL;

SELECT *
FROM DM 
WHERE DMDTC IS NULL;

/* To check the duplicate records */
SELECT SUBJID, COUNT(*) AS TOTAL_COUNT
FROM DM 
GROUP BY SUBJID 
HAVING COUNT(*) >1;

/* To check variables contain unexpected values */
SELECT*
FROM DM
WHERE SEX NOT IN('M','F');

SELECT*
FROM DM
WHERE ARM NOT IN('Investigational Drug','Placebo');

SELECT*
FROM DM
WHERE RACE NOT IN('WHITE','ASIAN','OTHER','BLACK OR AFRICAN AMERICAN');

SELECT*
FROM DM
WHERE COUNTRY NOT IN('IND');

/* To check numerical variables are reasonable */
SELECT *
FROM DM 
WHERE AGE <18 OR AGE >75;

/* To check the dates */
SELECT COUNT(*)
FROM DM 
WHERE DMDTC='2025-12-15';

/* To check the invalid SUBJID */
SELECT*
FROM DM
WHERE SUBJID NOT LIKE 'SUBJ[0-9][0-9][0-9]';

/* To check the age distrubution */
SELECT 
    MIN(AGE) AS MIN_AGE,
    MAX(AGE) AS MAX_AGE,
    AVG(CAST(AGE AS DECIMAL(10,2))) AS MEAN_AGE
FROM DM;

/* To check treatment counts */
SELECT ARM, COUNT(*) AS SUBJECT_COUNT
FROM DM 
GROUP BY ARM;

