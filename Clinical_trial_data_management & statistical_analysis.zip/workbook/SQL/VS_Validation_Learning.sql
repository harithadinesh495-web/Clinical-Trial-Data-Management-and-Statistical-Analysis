/* =========================================================
   Clinical Trial Data Validation
   Dataset: VS
   Purpose: Vital Signs Data Validation
   ========================================================= */
/* To check the structure of table */
SELECT* 
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME='VS';

SELECT DATA_TYPE,
       COLUMN_NAME,
       CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME='VS';  

/* To check the count of records */
SELECT COUNT(*) AS TOTAL_COUNTS
FROM VS;

/* To check the missing values */ 
SELECT *
FROM VS
WHERE STUDYID IS NULL
OR SUBJID IS NULL
OR VISIT IS NULL
OR VISITNUM IS NULL
OR VSDTC IS NULL
OR VSTESTCD IS NULL
OR VSTEST IS NULL
OR VSORRES IS NULL
OR VSORRESU IS NULL;

/* To check the duplicate records */
SELECT SUBJID,VISIT,VSTESTCD, COUNT(*)
FROM VS
GROUP BY SUBJID,VISIT,VSTESTCD
HAVING COUNT(*)>1;

/* To check the SUBJID validity */
SELECT VS.SUBJID
FROM VS
LEFT JOIN DM
ON VS.SUBJID=DM.SUBJID
WHERE DM.SUBJID IS NULL;

/* To check the visit consistency */
SELECT SUBJID,VISIT,VISITNUM, COUNT(*) AS N
FROM VS
GROUP BY SUBJID,VISIT,VISITNUM
HAVING COUNT(*)<>4
ORDER BY SUBJID ASC;

/* To check the date validity */
SELECT* 
FROM VS
WHERE VSDTC IS NULL; 

SELECT VISIT,VISITNUM,VSDTC, COUNT (*) AS N
FROM VS
GROUP BY VISIT,VISITNUM,VSDTC;

SELECT
    DM.SUBJID,
    DM.DMDTC,
    VS.VISIT,
    VS.VISITNUM,
    VS.VSDTC
FROM DM
INNER JOIN VS
    ON DM.SUBJID = VS.SUBJID
WHERE VS.VSDTC < DM.DMDTC;

/* To check numeric validity */
SELECT DISTINCT VSORRES
FROM VS
WHERE VSORRES IS NOT NULL
  AND TRY_CONVERT(DECIMAL(18,4), VSORRES) IS NULL;

/* To check the numeric range.
   NOTE: the protocol defines no vital-sign limits; these are project-defined review limits.
   Rows returned (e.g. SYSBP > 145) are for review, not automatic errors. */
SELECT *
FROM VS 
WHERE VSTESTCD='PULSE' 
AND (VSORRES < 40 OR VSORRES > 170);

SELECT *
FROM VS
WHERE VSTESTCD='DIABP'
AND (VSORRES <55 OR VSORRES>145);

SELECT *
FROM VS
WHERE VSTESTCD='SYSBP'
AND (VSORRES <100 OR VSORRES>145);

SELECT * 
FROM VS 
WHERE VSTESTCD='WEIGHT'
AND (VSORRES <40 OR VSORRES >160);

/* To check the unit consistency */
SELECT*
FROM VS 
WHERE VSTESTCD='WEIGHT'
AND VSORRESU<>'kg';

SELECT*
FROM VS 
WHERE VSTESTCD='PULSE'
AND VSORRESU<>'bpm';

SELECT*
FROM VS 
WHERE (VSTESTCD='SYSBP' 
OR VSTESTCD='DIABP') 
AND VSORRESU<>'mmHg';

/* To check terminology consistency */
SELECT *
FROM VS
WHERE (VSTESTCD='DIABP' OR VSTESTCD='SYSBP')
AND VSORRESU<>'mmHg';

SELECT *
FROM VS
WHERE VSTESTCD='PULSE'
AND VSORRESU<>'bpm';

SELECT *
FROM VS
WHERE VSTESTCD='WEIGHT'
AND VSORRESU<>'kg';

/* To check result/unit compatibility */
SELECT *
FROM VS
WHERE VSORRES IS NULL 
AND VSORRESU IS NULL;