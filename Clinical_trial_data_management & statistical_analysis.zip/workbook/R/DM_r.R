#T2DM Clinical Trial
#Demographic analysis-DM

#Load packages
library(dplyr)
library(ggplot2)
dm<-read.csv("DM.csv")

#Dimensions
dim(dm)

#Column names
names(dm)

#Data types
str(dm)

#First records
head(dm)

#Missing values
colSums(is.na(dm))

#Number of subjects
n_distinct(dm$SUBJID)
nrow(dm)
ncol(dm)

#Age summary
age_summary <- dm %>%
  summarise(
    N=n(),
    Mean=mean(AGE),
    Median=median(AGE),
    SD=sd(AGE),
    Min=min(AGE),
    Max=max(AGE)
  )

#Age by treatment summary
 Age_trt_summary <- dm %>%
  group_by(ARM) %>%
  summarise(
    N=n(),
    Median=median(AGE),
    Mean=mean(AGE),
    SD=sd(AGE),
    Max=max(AGE),
    Min=min(AGE)
  )

#Sex frequency
table(dm$SEX)

#Sex by treatment 
table(dm$SEX,dm$ARM)

#Sex percentage 
prop.table(table(dm$SEX,dm$ARM),margin = 2)*100

#Race frequency
table(dm$RACE)

#Race by treatment
table(dm$RACE,dm$ARM)

#Race percentage
prop.table(table(dm$RACE,dm$ARM),margin = 2)*100

#Country frequency
table(dm$COUNTRY)

#Country by treatment
table(dm$COUNTRY,dm$ARM)

#Sex summary
sex_summary <- dm %>%
 count(ARM,SEX) %>%
  group_by(ARM) %>%
  mutate(
    Percent= n/sum(n)*100
  )

#Race summary
race_summary <- dm %>%
 count(ARM,RACE) %>%
  group_by(ARM) %>%
  mutate(
    percent=n/sum(n) *100
  )

#Country summary
country_summary <- dm %>%
  count(ARM,COUNTRY) %>%
  group_by(ARM) %>%
  mutate(
    percent=n/sum(n) *100
  )

#Age histogram
ggplot(dm, aes(x=AGE))+
  geom_histogram(bins = 10,fill="steelblue",color="white")+
  labs(
    title = "Age Distribution",
    x = "Age (Years)",
    y = "Number of Subjects"
  )+
 theme_minimal()

#Age by treatment 
ggplot(dm, aes(x=AGE,y=ARM))+
  geom_boxplot()+
  labs(
    title = "Age by Treatment",
    x= "Age(Years)",
    y="Treatment Arm"
  )+
  theme_minimal()

#Sex bar chart by treatment 
ggplot(dm, aes(x=SEX))+
  geom_bar(bins=10,fill="steelblue",color="white")+
  labs(
    title = "Sex Distribution",
    x="Sex",
    y="Number of subjects"
  )+
  theme_minimal()

#Race bar chart by treatment
ggplot(dm, aes(x=ARM,fill=RACE))+
  geom_bar(fill="steelblue",color="white")+
  labs(
    title="Race by treatment",
    x="Treatment Arm",
    y="Number of subjects",
  fill="Race",
  )+
  theme_minimal()

#Exporting outputs
write.csv(
  age_summary,
  "DM_age_summary.csv",
  row.names= FALSE
)

write.csv(
  Age_trt_summary,
  "DM_age_trt_summary.csv",
  row.names = FALSE
)

write.csv(
  sex_summary,
  "DM_sex_summary.csv",
  row.names = FALSE
)

write.csv(
  race_summary,
  "DM_race_summary.csv",
  row.names = FALSE
)

