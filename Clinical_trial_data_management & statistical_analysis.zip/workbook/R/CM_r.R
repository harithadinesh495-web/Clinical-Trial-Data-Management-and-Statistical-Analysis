#T2DM Clinical Trial
#Concomitant Medications-CM

#Load cm dataset 
library(dplyr)
library(ggplot2)
cm <- read.csv("CM.csv")
dm <- read.csv("DM.csv")
cm <- cm %>%
  left_join(dm %>% 
              select(SUBJID,ARM),
            by="SUBJID")

#Dimensions 
dim(cm)

#Data types
str(cm)

#First 10 records
head(cm,10)

#Column names
colnames(cm)

#Missing values
sum(is.na(cm))

#Count unique subjects
n_distinct(cm$SUBJID)

#Duplicate records
cm %>%
  count(SUBJID,CMTRT,CMDOSE) %>%
  filter(n>1)

#Medication records by medication name
cm_rec <- cm %>%
  count(CMTRT) 

cm_rec

#Medication records by route
cm_route <- cm %>%
  count(CMROUTE)

cm_route

#Medication records by dose
cm_dose <- cm %>%
  count(CMDOSE)

cm_dose

#Medication records by indication
cm_ind <- cm %>%
  count(CMINDC)

cm_ind

#Medication records by treatmnet arm 
cm_arm <- cm %>%
  count(ARM)

cm_arm

#Medication records by sequence
cm_seq <- cm %>%
  count(CMSEQ)

cm_seq

#Conversion of medication start and end dates
cm <- cm %>% 
   mutate(
     CMENDTC=as.Date(CMENDTC),
     CMSTDTC=as.Date(CMSTDTC)
   )
str(cm)

#Medication duration
CM_DUR <- cm %>%
  mutate(
    CM_DUR=CMENDTC - CMSTDTC
  )
head(CM_DUR)

#Identifying missing start or end dates
cm_missing_dates <- cm %>%
  summarise(
    Missing_start=sum(is.na(CMSTDTC)),
    Missing_end=sum(is.na(CMENDTC))
  )

cm_missing_dates

#Medication record summary by treatment
cm_sum_trt <- cm %>%
  group_by(ARM) %>%
  count(CMTRT)

cm_sum_trt

#Medication routes by treatment
cm_rt_trt <- cm %>%
  group_by(ARM) %>%
  count(CMROUTE)

cm_rt_trt

#Medication dose by treatment
cm_dose_trt <- cm %>%
  group_by(ARM) %>%
  count(CMDOSE)

cm_dose_trt

#Treatment by arm
cm_trt_arm <- cm %>%
  group_by(ARM) %>%
  count(CMTRT)

cm_trt_arm

#Indications by treatment 
cm_ind_trt <- cm %>%
  group_by(ARM) %>%
  count(CMINDC)

cm_ind_trt

#Medication dose distribution
ggplot(cm_dose, aes(x=CMDOSE))+
  geom_histogram(bins=10,fill="steelblue",color="white")+
  labs(
    x="Dose of concomitant medication",
    y="Number of observations",
    title = "Distribution of medication dose"
  )+
  theme_minimal()

#Treatment records by treatment arm 
ggplot(cm_trt_arm, aes(x=CMTRT,y=ARM))+
  geom_col(fill="steelblue",color="white")+
  labs(
    x="Concomitant medication treatment",
    y="ARM",
    title = "Treatment records by tretment arm"
  )+
  coord_flip()+
  theme_minimal()

#Medication duration distribution
ggplot(CM_DUR, aes(x=CM_DUR))+
  geom_histogram(bins=10,fill="steelblue",colour = "white")+
  labs(
    x="Duration",
    y="Number of patients",
    title = "Duration distribution"
  )+
  theme_minimal()
