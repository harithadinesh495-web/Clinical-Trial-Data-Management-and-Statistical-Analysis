#T2DM Clinical Trial
#Exposure analysis-EX

#Load packages
library(dplyr)
library(ggplot2)

#Load dataset
ex <- read.csv("EX.csv")
dm <- read.csv("DM.csv")
ex <- ex %>%
  left_join(dm %>%
              select(SUBJID,ARM), by="SUBJID")

#Dimensions
dim(ex)

#Column names
colnames(ex)

#Data types
str(ex)

#First reccords 
head(ex,10)

#Missing values
n_distinct(ex)

#Duplicates 
ex %>%
  count(SUBJID,EXSTDTC,EXTRT) %>%
  filter(n>1)

#Exposure records by treatment
ex_trt <- ex %>%
  group_by(ARM) %>%
  count(SUBJID) 

ex_trt

#Unique treatment names
n_distinct(ex$EXTRT)

#Exposure by route
ex_route <- ex %>%
  group_by(EXROUTE) %>%
 count(SUBJID) 

ex_route

#Convert exposure dates 
ex <- ex %>%
  mutate(
    EXSTDTC=as.Date(EXSTDTC)
  )

str(ex$EXSTDTC)

#Exposure record counts by treatment 
ggplot(ex, aes(x=EXTRT))+
  geom_bar()+
  labs(
    x="Treatment",
    y="Number of exposure records",
    title = "Exposure record counts by treatment"
  )+
  theme_minimal()

#Dose distribution
ggplot(ex,aes(x=EXDOSE))+
  geom_histogram(bins=20)+
  labs(
    title = "Distribution of study drug dose",
    x="Dose",
    y="Number of exposure records"
  )+
  theme_minimal()
    
#Mean dose by treatment 
Mean_dose <- ex %>%
  group_by(EXTRT) %>%
  summarise(
    Mean=mean(EXDOSE)
  )
Mean_dose

ggplot(ex, aes(x = EXROUTE)) +
  geom_bar() +
  coord_flip() +
  labs(
    title = "Exposure Records by Route",
    x = "Route of Administration",
    y = "Number of Exposure Records"
  ) +
  theme_minimal()