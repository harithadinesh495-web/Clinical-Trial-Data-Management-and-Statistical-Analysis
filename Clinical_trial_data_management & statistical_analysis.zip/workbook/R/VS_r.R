#T2DM Clinical Trial
#Vital signs-VS

#Load packages
library(dplyr)
library(ggplot2)
vs<- read.csv("VS.csv")
lb <- read.csv("LB.csv")
dm <- read.csv("DM.csv")
vs <- vs %>%
      left_join(
        dm %>% select(SUBJID,ARM),
        by="SUBJID"
        )

#Dimensions
dim(vs)

#Column names
colnames(vs)

#Data types
str(vs)

#First records
head(vs)

#Missing values
colSums(is.na(vs))

#Unique values
n_distinct(vs$SUBJID)

#Duplicate logical records-SUBJID,VISITNUM,VSTESTCD
vs %>%
  count(SUBJID,VISITNUM,VSTESCD) %>%
  filter(n>1)

#Frequency of VSTESTCD
table(vs$VSTESTCD)

#Frequency of VSTEST
table(vs$VSTEST)

#Measurements across visit
table(vs$VSTEST,vs$VISIT)

#Measurements across unit
table(vs$VSORRESU,vs$VISIT)

#Visit frquency
table(vs$VISIT)


#Descriptive statistics of VSTEST
test_summary <- vs %>%
  group_by(ARM, VISIT, VSTEST) %>%
  summarise(
    N = n(),
    Mean = mean(VSORRES, na.rm = TRUE),
    Median = median(VSORRES, na.rm = TRUE),
    SD = sd(VSORRES, na.rm = TRUE),
    Min = min(VSORRES, na.rm = TRUE),
    Max = max(VSORRES, na.rm = TRUE),
    .groups = "drop"
  )
 test_summary
 
 #Baseline SYSBP
 Baseline_SYSBP <- vs %>%
   filter(VISIT=="Baseline") %>%
   summarise(
     N=n(),
     Mean=mean(VSORRES),
     Median=median(VSORRES),
     SD=sd(VSORRES),
     Maximum=max(VSORRES),
     Minimum=min(VSORRES)
   )
 Baseline_SYSBP
 
 #Week 24 SYSBP
 Week24_SYSBP <- vs %>%
   filter(VISIT=="Visit 5") %>%
   summarise(
     N=n(),
     SD=sd(VSORRES),
     Mean=mean(VSORRES),
     Median=median(VSORRES),
     Maximum=max(VSORRES),
     Minimum=min(VSORRES)
   )
 Week24_SYSBP
 
 #SYSBP Change from baseline by ARM
 baseline <- vs %>%
   filter(VISIT == "Baseline", VSTESTCD == "SYSBP") %>%
   select(SUBJID, Base_SYSBP = VSORRES)
 
 week24 <- vs %>%
   filter(VISITNUM == 24, VSTESTCD == "SYSBP") %>%
   select(SUBJID, Week24_SYSBP = VSORRES)
 
 change_sysbp <- baseline %>%
   left_join(week24, by = "SUBJID") %>%
   mutate(Change_SYSBP = Week24_SYSBP - Base_SYSBP)
 
 change_sysbp
 
 change_sysbp <- change_sysbp %>%
   left_join(dm %>% select(SUBJID, ARM), by = "SUBJID")
 
 sysbp_change_by_arm <- change_sysbp %>%
   group_by(ARM) %>%
   summarise(
     N = sum(!is.na(Change_SYSBP)),
     Mean_Change = mean(Change_SYSBP, na.rm = TRUE),
     SD = sd(Change_SYSBP, na.rm = TRUE),
     Median_Change = median(Change_SYSBP, na.rm = TRUE),
     Minimum = min(Change_SYSBP, na.rm = TRUE),
     Maximum = max(Change_SYSBP, na.rm = TRUE),
     .groups = "drop"
   )
 
 sysbp_change_by_arm
 
#DIABP change from baseline by ARM
 baseline_diabp <- vs %>%
   filter(VSTESTCD=="DIABP",VISIT=="Baseline") %>%
   select(SUBJID, Base_diabp=VSORRES)
 
 week_24_diabp <- vs %>%
   filter(VSTESTCD=="DIABP",VISITNUM== 24) %>%
   select(SUBJID, Week24_diabp=VSORRES)
 
 Change_diabp<- baseline_diabp %>%
   left_join(week_24_diabp,by="SUBJID") %>%
   left_join(dm %>% select(SUBJID,ARM),by="SUBJID") %>%
   mutate(Change_diabp= Week24_diabp - Base_diabp
   )
 
 Change_diabp
 
 Change_diabp_by_arm <- Change_diabp %>%
   group_by(ARM) %>%
   summarise(
     N=n(),
     Mean=mean(Change_diabp,na.rm = TRUE),
     Median= median(Change_diabp,na.rm = TRUE),
     SD=sd(Change_diabp,na.rm = TRUE),
     Maximum=max(Change_diabp,na.rm = TRUE),
     Minimum=min(Change_diabp,na.rm = TRUE),
     .groups = "drop"
   )
 Change_diabp_by_arm
 
#Bodyweight change by arm
 Baseline_weight <- vs %>%
   filter(VSTESTCD=="WEIGHT",VISIT=="Baseline") %>%
   select(SUBJID, Base_weight=VSORRES)
 
 Week_24_weight <- vs %>%
   filter(VSTESTCD=="WEIGHT",VISITNUM==24) %>%
   select(SUBJID, week24_weight=VSORRES)
 
 Change_weight<- Baseline_weight %>%
   left_join(Week_24_weight,by="SUBJID") %>%
   left_join(dm %>% select(SUBJID,ARM),by="SUBJID")%>% 
               mutate(Change_weight = Base_weight - week24_weight
                      )
 
 Change_weight_by_arm <- Change_weight %>%
   group_by(ARM) %>%
   summarise(
     N=n(),
     Mean=mean(Change_weight,na.rm = TRUE),
     Median=median(Change_weight,na.rm = TRUE),
     SD=sd(Change_weight,na.rm = TRUE),
     Maximum=max(Change_weight),
     Minimum=min(Change_weight),
     .groups = "drop"
   )
 
 Change_weight_by_arm
 
#SYSBP distribution
 ggplot(vs, aes(x=VSORRES))+
   geom_histogram(bins=20,fill="steelblue",colour = "white")+
   labs(
     X="SYSBP",
     Y="No.of obsrevations",
     Title="SYSBP distribution"
   )+
   theme_minimal()
 
#DIABP distribution
 ggplot(vs,aes(x=VSORRES))+
   geom_histogram(bins=20,fill="steelblue",color="white")+
   labs(
     x="DIABP",
     Y="No.of observations",
     Title="DIABP distribution"
   )+
   theme_minimal()
 
#Pulse distribution
 ggplot(vs,aes(x=VSORRES))+
          geom_histogram(bins=10,fill = "steelblue",colour = "white")+
   labs(
     X="PULSE",
     Y="No.of observations",
     title = "Pulse distribution"
   )+
   theme_minimal()
 
#Weight distribution
 ggplot(vs,aes(x=VSORRES))+
   geom_histogram(bins=10,fill = "steelblue",colour = "white")+
 labs(
   X="WEIGHT",
   Y="No.of observations",
   title = "Weight distrubution"
 )+
   theme_minimal()
 
#SYSBP boxplot by ARM
 ggplot(vs, aes(x=VSORRES ,y=ARM ))+
    geom_boxplot()+      
   labs(
     X="SYSBP",
     Y="ARM",
     title = "SYSBP by treatment"
   )+
 theme_minimal()
 
#DIABP boxplot by ARM 
ggplot(vs,aes(x=VSORRES,y=ARM))+
  geom_boxplot()+
  labs(
    X="DIABP",
    Y="ARM",
    title = "DIABP by treatment"
  )+
 theme_minimal()
 

#WEIGHT boxplot by ARM 
ggplot(vs,aes(x=VSORRES,y=ARM))+
  geom_boxplot()+
  labs(
    X="WEIGHT",
    Y="ARM",
    title = "WEIGHT by treatment"
  )+
  theme_minimal()
  
 
#SYSBP by ARM and visit
library(dplyr)
library(ggplot2)
sysbp_summary <- vs %>%
  filter(VSTESTCD=="SYSBP") %>%
  group_by(ARM,VISIT,VISITNUM) %>%
  summarise(
    N=n(),
    SD=sd(VSORRES,na.rm = TRUE),
    MEAN=mean(VSORRES,na.rm= TRUE),
    .groups = "drop"
  )
sysbp_summary
ggplot(sysbp_summary, aes(x=VISITNUM,y=MEAN,color=ARM,group=ARM))+
  geom_line(linewidth=1)+
  geom_point(size=3)+
  labs(
    title = "SYSBP summary by ARM and VISIT",
    x="VISITNUM",
    y="Mean",
    color= "treatment ARM"
  )+
  theme_minimal()
 
#DIABP by ARM and visit
 diabp_summary <- vs %>%
   filter(VSTESTCD=="DIABP") %>%
   group_by(ARM,VISIT,VISITNUM) %>%
   summarise(
     N=n(),
     Mean=mean(VSORRES,na.rm=TRUE),
     SD=sd(VSORRES,na.rm = TRUE),
     .groups = "drop"
   )
 ggplot(diabp_summary,aes(x=VISITNUM,y=Mean,color=ARM,group=ARM))+
   geom_point(size=2)+
   geom_line(linewidth = 1)+
   labs(
     x="VISITNUM",
     y="Mean",
     title="SYSBP summary by ARM and VISIT",
       color="Treatment ARM"
   )+ 
   theme_minimal()
 
#WEIGHT by ARM and visit
 weight_summary <- vs %>%
   filter(VSTESTCD=="WEIGHT") %>%
   group_by(ARM,VISIT,VISITNUM) %>%
   summarise(
     N=n(),
     SD=sd(VSORRES,na.rm = TRUE),
     Mean=mean(VSORRES,na.rm = TRUE)
   )
 
 ggplot(weight_summary,aes(x=VISITNUM,y=Mean,color=ARM,group=ARM))+
   geom_point(size=2)+
   geom_line(linewidth = 3)+
   labs(
     x="VISITNUM",
     y="Mean",
     title = "Weight by ARM and VISIT",
     color="ARM"
   )+
   theme_minimal()
   
#VS overall summary  
library(dplyr)
vs_overall_summary <- vs %>%
  group_by(VSTESTCD) %>%
  summarise(
    N=n(),
    Mean=mean(VSORRES,na.rm=TRUE),
    Median=median(VSORRES,na.rm = TRUE),
    SD=sd(VSORRES,na.rm = TRUE),
    Maximum=max(VSORRES,na.rm = TRUE),
    Minimum=min(VSORRES,na.rm = TRUE),
    .groups = "drop"
  )
 vs_overall_summary
 
#VS treatment summary
 vs_treatment_summary <- vs %>%
   group_by(ARM) %>%
   summarise(
     N=n(),
     Mean=mean(VSORRES,na.rm=TRUE),
     Median=median(VSORRES,na.rm = TRUE),
     SD=sd(VSORRES,na.rm = TRUE),
     Maximum=max(VSORRES,na.rm = TRUE),
     Minimum=min(VSORRES,na.rm = TRUE),
     .groups = "drop"
   )
 vs_treatment_summary 

#VS visit summary
 vs_visit_summary <- vs %>%
   group_by(VISIT) %>%
   summarise(
     N=n(),
     Mean=mean(VSORRES,na.rm=TRUE),
     Median=median(VSORRES,na.rm = TRUE),
     SD=sd(VSORRES,na.rm = TRUE),
     Maximum=max(VSORRES,na.rm = TRUE),
     Minimum=min(VSORRES,na.rm = TRUE),
     .groups = "drop"
   )
 vs_visit_summary
#VS treatment visit summary
 vs_trt_visit_summary <- vs %>%
   group_by(ARM,VISIT) %>%
   summarise(
     N=n(),
     Mean=mean(VSORRES,na.rm=TRUE),
     Median=median(VSORRES,na.rm = TRUE),
     SD=sd(VSORRES,na.rm = TRUE),
     Maximum=max(VSORRES,na.rm = TRUE),
     Minimum=min(VSORRES,na.rm = TRUE),
     .groups = "drop"
   )
 vs_trt_visit_summary

 