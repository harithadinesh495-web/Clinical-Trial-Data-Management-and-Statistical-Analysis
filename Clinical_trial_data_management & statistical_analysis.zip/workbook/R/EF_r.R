#T2DM Clinical Trial
#Efficacy analysis-EF

#Load packages
library(dplyr)
library(ggplot2)

#Load dataset
ef <- read.csv("EFC.csv")
dm <- read.csv("DM.csv")
ef <- ef %>%
  left_join(dm %>% select(SUBJID,ARM),
            by="SUBJID")

#Dimensions
dim(ef)

#Data types
str(ef)

#Column names
colnames(ef)

#First records
head(ef,10)

#Missing values
n_distinct(ef$SUBJID)

#Duplicate SUBJID records
ef_duplicate <- ef %>% 
  count(SUBJID,ARM) %>%
  filter(n > 1)

ef_duplicate

#Missing HbA1c 
Missing_Hba1c <- ef %>%
  summarise(
    Base_Hba1c=sum(is.na(BASE_HBA1C)),
    W24_HBA1C=sum(is.na(W24_HBA1C)),
    CHG_HBA1C=sum(is.na(CHG_HBA1C))
  )

Missing_Hba1c

#Chg_HbA1c
ef <- ef %>%
  mutate(
    Chg_HbA1c=W24_HBA1C - BASE_HBA1C
  )

ef

#Change in HbA1c
ef_chg <- ef %>%
  select(SUBJID,CHG_HBA1C,Chg_HbA1c)

ef_chg

#Summarise baseline by arm
Base_summary_hba1c <- ef %>%
  group_by(ARM) %>%
  summarise(
    N=n(),
    Mean=mean(BASE_HBA1C),
    Median=median(BASE_HBA1C),
    SD=sd(BASE_HBA1C),
    Maximum=max(BASE_HBA1C),
    Minimum=min(BASE_HBA1C)
  )

Base_summary_hba1c

#Summarise week24 hba1c
w24_summary_hba1c <- ef %>%
  group_by(ARM) %>%
  summarise(
    N=n(),
    Mean=mean(W24_HBA1C),
    Median=median(W24_HBA1C),
    Maximum=max(W24_HBA1C),
    Minimum=min(W24_HBA1C),
    SD=sd(W24_HBA1C)
  )

w24_summary_hba1c

#Baseline vs Week24
ggplot(ef, aes(x=BASE_HBA1C,y=W24_HBA1C ))+
  geom_point(size = 1)+
  geom_abline(slope=1,intercept=0,linetype="dashed")+
  labs(
    x="Baseline HbA1c",
    y="Week 24 HbA1c",
    title = "Baseline vs Week24 HbA1c"
  )+
  theme_minimal()

#Change by treatment '
ggplot(ef, aes(x=ARM,y=CHG_HBA1C))+
  geom_boxplot()+
  stat_summary(fun=mean,geom="point",shape=23,size=3,fill="white")+
  labs(
    x="Treatment",
    y="Change in HbA1c (%)",
    title = "Change in HbA1c from Baseline to Week 24 by treatment"
  )+
  theme_minimal()

