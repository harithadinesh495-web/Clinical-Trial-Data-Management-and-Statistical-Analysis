#T2DM Clinical Trial
#Laboratory analysis-LB

#Load packages
library(dplyr)
library(ggplot2)
lb <- read.csv("LB.csv")
dm <- read.csv("DM.csv")
lb <- lb %>%
  left_join(
    dm %>% select(SUBJID, ARM),
    by = "SUBJID"
  )

#Dimensions
dim(lb)

#Column names
colnames(lb)

#Data types
str(lb)

#First records
head(lb,10)

#Missing values
colSums(is.na(lb))

#Unique subjects
n_distinct(lb$SUBJID)

#Duplicate logical records
lb %>%
  count(SUBJID,LBTESTCD,VISITNUM) %>%
  filter(n>1)

#Frequency of LBTESTCD
table(lb$LBTESTCD)

#Frequency of LBTEST 
table(lb$LBTEST)

#Count of test at each visit 
table(lb$LBTEST,lb$VISIT)

#Count of test in each unit
table(lb$LBTEST,lb$LBSTRESU)

#Visit frequency
table(lb$VISIT)

#Overall lab summary 
lb_summary <- lb %>%
  group_by(LBTESTCD,ARM,VISITNUM) %>%
  summarise(
    N=sum(!is.na(LBSTRESN)),
    Mean=mean(LBSTRESN,na.rm=TRUE),
    Median=median(LBSTRESN,na.rm=TRUE),
    SD=sd(LBSTRESN,na.rm = TRUE),
    Maximum=max(LBSTRESN,na.rm = TRUE),
    Minimum=min(LBSTRESN,na.rm = TRUE),
    .groups = "drop"
  )
lb_summary

#Lab summary by ARM
LB_treatment_summary <- lb %>%
  group_by(LBTESTCD,ARM) %>%
  summarise(
    N=n(),
    Mean= mean(LBSTRESN, na.rm= TRUE),
    Median= median(LBSTRESN, na.rm= TRUE),
    SD= sd(LBSTRESN, na.rm = TRUE),
    Minimum= min(LBSTRESN,na.rm = TRUE),
    Maximum= max(LBSTRESN, na.rm = TRUE),
    .groups = "drop"
  )
LB_treatment_summary

#Lab summary by ARM and VISIT
LB_arm_visit_summary <- lb %>%
  group_by(LBTESTCD,ARM,VISIT) %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN, na.rm=TRUE),
    Median=median(LBSTRESN,na.rm=TRUE),
    SD=sd(LBSTRESN,na.rm=TRUE),
    Minimum=min(LBSTRESN,na.rm=TRUE),
    Max=max(LBSTRESN,na.rm=TRUE),
    .groups = "drop"
  )
LB_arm_visit_summary

#hba1c summary
hba1c <- lb %>%
  filter(LBTESTCD=="HBA1C")
hba1c_summary<- hba1c %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )
hba1c_summary
 
#Baseline HbA1c summary
baseline_hba1c <- hba1c %>%
  filter(VISITNUM==0) 
baseline_hba1c %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN),
  )
baseline_hba1c

#week 24 hba1c summary
week24_hba1c <- hba1c %>%
  filter(VISITNUM==24)

week24_hba1c %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )
week24_hba1c


#hba1c by visit
hba1c %>%
  group_by(VISIT) %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN),
    .groups = "drop"
  )

#hba1c by treatment and visit
hba1c_trt_visit <- hba1c %>%
  group_by(ARM,VISIT) %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)  
  )
hba1c_trt_visit

#Change from baseline
baseline <- hba1c %>%
  filter(VISITNUM == 0) %>%
  select(SUBJID, BASE_HBA1C = LBSTRESN)
baseline

week24 <- hba1c %>%
  filter(VISITNUM==24) %>%
  select(SUBJID, WEEK24_HBA1C = LBSTRESN)
week24

hba1c_change <- baseline %>%
  left_join(week24, by="SUBJID") %>%
left_join(
  dm %>% select(SUBJID,ARM),
          by="SUBJID"
  )%>%
  mutate(
    hba1c_change = WEEK24_HBA1C - BASE_HBA1C
  )

head(hba1c_change)

#Change from baseline by treatment
change_by_trt <- hba1c_change %>%
  group_by(ARM) %>%
  summarise(
    N=n(),
    Mean=mean(hba1c_change),
    Median=median(hba1c_change),
    SD=sd(hba1c_change),
    Maximum=max(hba1c_change),
    Minimum=min(hba1c_change)
  )
change_by_trt

#Extract FBG
fbg <- lb %>%
  filter(LBTESTCD=="FBG")

#FBG by Visit
fbg_visit <- fbg %>%
  group_by(VISIT) %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )
fbg_visit

#FBG by treatment and visit
fbg_trt_visit <- fbg %>%
  group_by(ARM,VISIT) %>%
  summarise(
    N=n(),
    Mean=mean(LBSTRESN),
    Median=median(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )
fbg_trt_visit

#Baseline FBG
fbg_baseline <- fbg %>%
  filter(VISIT=="Baseline")

fbg_baseline %>%
  summarise(
    N=n(),
    Median=median(LBSTRESN),
    Mean=mean(LBSTRESN),
    SD=sd(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )

#Week24 FBG
week24_fbg <- fbg %>%
  filter(VISIT=="Week 24")

week24_fbg %>%
  summarise(
    N=n(),
    SD=sd(LBSTRESN),
    Median=median(LBSTRESN),
    Mean=mean(LBSTRESN),
    Maximum=max(LBSTRESN),
    Minimum=min(LBSTRESN)
  )

#Change from baseline
fbg_baseline <- lb %>%
  filter(VISIT=="Baseline") %>%
  select(SUBJID, Baseline_fbg=LBSTRESN)

fbg_week24 <- lb %>%
  filter(VISIT=="Final Visit") %>%
  select(SUBJID,week24_fbg=LBSTRESN)

change_fbg <- fbg_baseline %>%
  left_join(fbg_week24,
            by="SUBJID") %>%
  left_join(dm %>% select(SUBJID,ARM),
            by="SUBJID"
            ) %>%
            mutate(
    change_fbg=week24_fbg - Baseline_fbg
  )
 change_fbg
 
#Change from baseline by treatment
fbg_change_by_trt <-change_fbg %>%
  group_by(ARM) %>%
  summarise(
    N=n(),
    Mean=mean(change_fbg),
      Median=median(change_fbg),
    SD=sd(change_fbg),
    Maximum=max(change_fbg),
    Minimum=min(change_fbg)
  )
fbg_change_by_trt

#hba1c distribution
ggplot(hba1c, aes(x=LBSTRESN))+
  geom_histogram(bins=20,fill="steelblue",color="white")+
  labs(
    title = "HBA1C distribution",
    x="HbA1c (%)",
    y="Number of observations"
  )+
theme_minimal()

#hba1c by treatment
ggplot(hba1c, aes(x=ARM,y=LBSTRESN))+
  geom_boxplot()+
  labs(
    title = "HbA1c by treatment",
    x="Treatment",
    y="HbA1c (%)"
  )+
  theme_minimal()

#hba1c by treatment and visit
hba1c_trt_visit_plot <- hba1c %>%
  group_by(ARM, VISIT, VISITNUM) %>%
  summarise(
    Mean_HBA1C = mean(LBSTRESN),
    .groups = "drop"
  )

ggplot(
  hba1c_trt_visit_plot,
  aes(x = VISITNUM, y = Mean_HBA1C, group = ARM, linetype = ARM)
) +
  geom_line() +
  geom_point() +
  scale_x_Ncontinuous(
    breaks = c(0, 3, 5, 24)
  ) +
  labs(
    title = "Mean HbA1c by Treatment and Visit",
    x = "Visit",
    y = "Mean HbA1c (%)",
    linetype = "Treatment"
  ) +
  theme_minimal()

#creatinine by treatment 
fbg <- lb %>%
  filter(LBTESTCD == "FBG")

fbg_trt_visit_plot <- fbg %>%
  group_by(ARM, VISIT, VISITNUM) %>%
  summarise(
    Mean_FBG = mean(LBSTRESN),
    .groups = "drop"
  )

ggplot(
  fbg_trt_visit_plot,
  aes(x = VISITNUM, y = Mean_FBG, group = ARM, linetype = ARM)
) +
  geom_line() +
  geom_point() +
  labs(
    title = "Mean FBG by Treatment and Visit",
    x = "Visit",
    y = "Mean FBG (mg/dL)",
    linetype = "Treatment"
  ) +
  theme_minimal()

#ALT by treatment
creatinine <- lb %>%
  filter(LBTESTCD == "CREAT")

ggplot(creatinine, aes(x = ARM, y = LBSTRESN)) +
  geom_boxplot() +
  labs(
    title = "Creatinine by Treatment",
    x = "Treatment",
    y = "Creatinine (mg/dL)"
  ) +
  theme_minimal()

#AST by treatment
ast <- lb %>%
  filter(LBTESTCD == "AST")

ggplot(ast, aes(x = ARM, y = LBSTRESN)) +
  geom_boxplot() +
  labs(
    title = "AST by Treatment",
    x = "Treatment",
    y = "AST (U/L)"
  ) +
  theme_minimal()

#HGB by treatment
hgb <- lb %>%
  filter(LBTESTCD == "HGB")

ggplot(hgb, aes(x = ARM, y = LBSTRESN)) +
  geom_boxplot() +
  labs(
    title = "HGB by Treatment",
    x = "Treatment",
    y = "Hemoglobin (g/dL)"
  ) +
  theme_minimal()