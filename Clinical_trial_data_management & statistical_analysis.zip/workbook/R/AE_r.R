#T2DM Clinical Trial
#Adverse Events-AE

#Load AE dataset
library(dplyr)
library(ggplot2)
dm <- read.csv("DM.csv")
lb <- read.csv("LB.csv")
vs <- read.csv("VS.csv")
ae <- read.csv("AE.csv")
ae <- ae %>%
  left_join(dm %>% select(SUBJID,ARM),
            by="SUBJID")

#Check dimensions
dim(ae)

#Column names
colnames(ae)

#Data types
str(ae)

#First records
head(ae,10)

#Missing values
colSums(is.na(ae))

#Unique subjects
n_distinct(ae$SUBJID)

#Duplicate records
ae %>%
  count(SUBJID,AESEV,AESER) %>%
  filter(n>1)

#Frequency of AE terms
ae %>%
  count(AETERM)

#Event counts by severity
ae %>%
  count(AESEV)

#Serious adverse events count
ae %>%
  filter(AESER=="Y") %>%
  count(AESER)


#Invsetigator assessed relationships to treatment  
ae_inv <- ae %>%
  group_by(AEREL,ARM) %>%
  summarise(
    N=n(),
    .groups = "drop"
  )
ae_inv

#Event count by subject 
ae_count <- ae %>%
  group_by(AETERM) %>%
  count(SUBJID)

ae_count

#Event count by treatment arm 
ae_trt_count <- ae %>%
  group_by(ARM) %>%
  count(AETERM)

ae_trt_count

#Severity by treatment 
ae_sev_trt <- ae %>%
  group_by(ARM) %>%
  count(AESEV)

ae_sev_trt

#Seriousness by treatment
ae_ser_trt <- ae %>%
  group_by(ARM) %>%
  count(AESER)

ae_ser_trt

#Load package
library(lubridate)

#Convert AE   start date and end date
ae <- ae %>%
  mutate(
    AEENDTC=as.Date(AEENDTC),
    AESTDTC=as.Date(AESTDTC)
  )
str(ae)

#Calculate   AE duration
ae_dur <- ae %>%
  select(SUBJID,AETERM,AESEV,AEREL,ARM,AEENDTC,AESTDTC) %>%
  mutate(
    AE_Duration = as.numeric(AEENDTC - AESTDTC)
  )

ae_dur

#Identify   missing start or end dates
ae_missing_dates <- ae %>%
  summarise(
    Missing_start=sum(is.na(AESTDTC)),
    Missing_end=sum(is.na(AEENDTC))
  )

ae_missing_dates

#Categorise   AE duration
ae_dur_cat <- ae %>%
  mutate(
    AE_Duration_Category = case_when(
      is.na(AE_Duration) ~ "Unknown",
      AE_Duration <= 3 ~ "1-3 days",
      AE_Duration <= 7 ~ "4-7 days",
      AE_Duration > 7 ~ "More than 7 days"
    )
  )
ae_dur_cat
#AE already merged with DM (ARM) at the top of the script
#AE frequency by treatment
ae_freq <- ae %>%
  count(ARM)

ggplot(ae_freq, aes(x=ARM,y=n))+
  geom_col()+
  labs(
    x="ARM",
    y="AE_frequency",
    title = "AE frequency by treatment"
  )+
  theme_minimal()
  
#AE severity distribution
ae_sev <- ae %>%
  count(AESEV)

ggplot(ae_sev, aes(x=AESEV,y=n))+
  geom_col()+
  labs(
    x="SEVERITY",
    y="AE severity",
    title = "AE severity distribution"
  )+
  theme_minimal()

#Serious versus non-serious events
ae_serious <- ae %>% 
  count(ARM,AESER)

ggplot(ae_serious, aes(x=ARM,y=n,fill=AESER))+
  geom_col(position="dodge")+
  labs(
    x="Treatment",
    y="Number of adverse events",
    title = "Serious vs non-serious"
  )+
  theme_minimal()

#Most frequently reported AE terms
aeterm_freq <- ae %>%
  count(AETERM)

ggplot(aeterm_freq, aes(x=AETERM,y=n))+
  geom_col()+
  coord_flip()+
  labs(
    x="Adverse event term",
    y="Number",
    title = "Most frequently reported AE terms"
  )+
  theme_minimal()
  
#AE duration distribution
ae_dur_dist <- ae %>%
  count(AE_Duration)

ggplot(ae_dur_dist, aes(x=AE_Duration,y=n))+
  geom_col()+
  labs(
    x="AE duration",
    y="No.of days",
    title = "Adverse event duration"
  )+
  theme_minimal()

