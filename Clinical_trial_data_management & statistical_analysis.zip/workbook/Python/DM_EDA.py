#=========================================================
#=========================================================
#T2DM Clinical Trial
#Demographics Analysis-DM
#
#=========================================================
#=========================================================

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)

print("Connection successful!")

#Load DM dataset 

dm = pd.read_sql("SELECT * FROM dbo.DM", connection)

#Dimensions
print(dm.shape)

#Column names
print(dm.columns)

#Data types
print(dm.dtypes)

#Descriptive statistics
print(dm.describe())

#First and last few rows
print(dm.head())
print(dm.tail())

#Information about DM
print(dm.info())

#Length
print(len(dm))

#Unique SUBJIID
print(dm["SUBJID"].nunique())

#Duplicate SUBJID
print(dm["SUBJID"].duplicated())
print(dm[dm["SUBJID"].duplicated()])

#Missing values
print(dm.isna().sum())
print(dm.isna().sum()[dm.isna().sum()>0])

#Age descriptive statistics
print(dm["AGE"].describe())

#Age range
print(dm["AGE"].min(),dm["AGE"].max())

#Outside Age range
print(dm[~dm["AGE"].between (18,75)])

#Age distribution freq and percent
age_frq=dm["AGE"].value_counts(dropna=True)
age_percent=dm["AGE"].value_counts(dropna=True,normalize=True)*100
age_summary=pd.DataFrame({
    "FREQUENCY":age_frq,
    "PERCENT":age_percent.round(1)
    })
print(age_summary)

#Sex distribution freq and percent
sex_freq=dm["SEX"].value_counts(dropna=False)
sex_percent=dm["SEX"].value_counts(dropna=False, normalize=True)*100
sex_summary=pd.DataFrame({
    "FREQUENCY":sex_freq,
    "PERCENT":sex_percent.round(1)
    })
print(sex_summary)

#Arm distrubution freq and percent
arm_freq=dm["ARM"].value_counts(dropna=False)
arm_percent=dm["ARM"].value_counts(dropna=False,normalize=True)*100
arm_summary=pd.DataFrame({
    "FREQUENCY":arm_freq,
    "PERCENT":arm_percent.round(1)
    })
print(arm_summary)

#Race distribution freq and percent
race_freq=dm["RACE"].value_counts(dropna=False)
race_percent=dm["RACE"].value_counts(dropna=False,normalize=True)*100
race_summary=pd.DataFrame({
    "FREQUENCY":race_freq,
    "PERCENT":race_percent.round(1)
    })
print(race_summary)

#Country distribution
country_freq=dm["COUNTRY"].value_counts(dropna=False)
country_percent=dm["COUNTRY"].value_counts(dropna=False,normalize=True)*100
country_summary=pd.DataFrame({
    "FREQUENCY":country_freq,
    "PERCENT":country_percent.round(1)
    })
print(country_summary)

#Treatment × Sex Cross-tabulation of treatment and sex
print(pd.crosstab(dm["ARM"],dm["SEX"]))

#Treatment × Race	Cross-tabulation of treatment and race
print(pd.crosstab(dm["ARM"],dm["RACE"]))

#Treatment × Age Compare age distribution between treatment groups
print(dm.groupby('ARM')['AGE'].describe())
dm.boxplot(column='AGE',by='ARM')
print(dm.groupby('ARM')['AGE'].agg(["count","mean","median","std","min","max"]))

#Minimum and maximum DMDTC
dm['DMDTC']=pd.to_datetime(dm['DMDTC'])
print(dm['DMDTC'].min())
print(dm['DMDTC'].max())

#One record per subject  
print(dm['SUBJID'].is_unique)

#Demographic summary 
summary=dm.groupby('ARM').agg(
    N=('SUBJID','count'),
    Mean_Age=('AGE','mean'),
    SD_Age=('AGE','std'),
    Min_Age=('AGE','min'),
    Max_Age=('AGE','max')
    )
print(summary)
sex_summary=pd.crosstab(dm['ARM'],dm['SEX'],normalize='index')*100
print(sex_summary)

#Age histogram
import matplotlib.pyplot as plt
dm.hist(column='AGE',by='ARM',bins=15)
plt.suptitle('Age distribution by treatment')
plt.show()

#Sex distribution 
pd.crosstab(dm['ARM'],dm['SEX']).plot(kind='bar')
plt.title('Sex distribution by treatment arm')
plt.xlabel('Treatment Arm')
plt.ylabel('Count')
plt.show()

#Race distribution by treatment arm
pd.crosstab(dm['ARM'],dm['RACE']).plot(kind='bar',stacked=True)
plt.title('Race distribution by treatment arm')
plt.xlabel('Treatment Arm')
plt.ylabel('Count')
plt.show()

#Age spread by treatment arm
dm.boxplot(column='AGE',by='ARM')
plt.title('Age spread by treatment arm')
plt.suptitle('')
plt.xlabel('Treatment Arm')
plt.ylabel('Age')
plt.show()

#Overall sex proportion 
dm['SEX'].value_counts().plot(kind='pie',autopct='%1.1f%%')
plt.title('Overall sex proportion')
plt.ylabel('')
plt.show()





