#T2DM Clinical Trial
#Concomitant medications analysis-CM

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load CM dataset
cm=pd.read_sql("SELECT* FROM CM", connection)

#Load AE dataset
ae=pd.read_sql("SELECT* FROM AE", connection)

#Load VS datset
vs=pd.read_sql("SELECT * FROM VS", connection)

#Load LB dataset
lb=pd.read_sql("SELECT * FROM LB",connection)

#Load DM dataset
dm=pd.read_sql("SELECT* FROM DM",connection)

#Dataset dimensions
print(cm.shape)

#Column names
print(cm.columns)

#Data types
print(cm.dtypes)

#Missing values
print(cm.isnull().sum())

#Unique values
print(cm["CMTRT"].unique())
print(cm["CMTRT"].nunique())

#Duplicate logical records
print(cm.duplicated(subset=["SUBJID","CMSEQ"]).sum())

#Treatment distribution
print(cm["CMTRT"].value_counts())

#CM records for each treatment arm
cm_trt=cm.merge(
    dm[["SUBJID","ARM"]],
       on="SUBJID")
print(cm_trt.groupby("ARM")["CMDOSE"].agg(
    ["count","std","mean"]
    ))

#Route distribution
print(cm["CMROUTE"].value_counts())
print(cm["CMROUTE"].unique())
print(cm["CMROUTE"].nunique())

#Treatment/medication route frequency
cm_route = pd.crosstab(
    cm_trt["ARM"],
    cm["CMROUTE"]
)
print(cm_route)

#Date conversion
print(cm[["CMSTDTC","CMENDTC"]].dtypes)
cm["CMSTDTC"]=pd.to_datetime(cm["CMSTDTC"])
cm["CMENDTC"]=pd.to_datetime(cm["CMENDTC"])
print(cm[["CMSTDTC","CMENDTC"]].dtypes)

#Duration calculation
cm["cm_duration"]=cm["CMENDTC"] - cm["CMSTDTC"]
print(cm[["SUBJID","CMSTDTC","CMENDTC","cm_duration"]])

#Subject level analysis
cm_per_subject = cm.groupby("SUBJID").size()
print(cm_per_subject)

#Medication frequency
med_frequency = cm["CMTRT"].value_counts()
import matplotlib.pyplot as plt
med_frequency.plot(kind="bar")
plt.xlabel("Medication")
plt.ylabel("Number of CM Records")
plt.title("Concomitant Medication Frequency")
plt.xticks(rotation=45)
plt.show()

#Dose distribution
cm["CMDOSE"].describe()
cm["CMDOSE"].plot(
    kind="hist",
    bins=20
)
plt.xlabel("Dose")
plt.ylabel("Frequency")
plt.title("Concomitant Medication Dose Distribution")
plt.show()
