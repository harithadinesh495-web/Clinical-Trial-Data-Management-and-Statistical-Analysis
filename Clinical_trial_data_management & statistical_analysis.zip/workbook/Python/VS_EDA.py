#T2DM Clinical Trial
#Vital Signs Analysis-VS

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load VS datset
vs=pd.read_sql("SELECT * FROM VS", connection)

#Load LB dataset
lb=pd.read_sql("SELECT * FROM LB",connection)

#Load DM dataset
dm=pd.read_sql("SELECT* FROM DM",connection)

#Dataset dimensions
print(vs.shape)

#Column names
print(vs.columns)

#Data types
print(vs.dtypes)

#Missing values
print(vs.isnull().sum())

#Duplicate logical records
print(vs.duplicated(subset=["SUBJID","VSTEST","VISIT"]).sum())

#Unique subjects
print(vs["SUBJID"].nunique())

#SYSBP/DIABP distribution
sysbp=vs[vs["VSTESTCD"]=="SYSBP"]
diabp=vs[vs["VSTESTCD"]=="DIABP"]
print(sysbp["VSORRES"].agg([
    "count","mean","std","median","min","max"
    ]))
print(diabp["VSORRES"].agg([
    "count","mean","std","median","min","max"
    ]))

#Descriptive statistics of each test
print(vs.groupby("VSTEST")["VSORRES"].agg([
        "count","mean","std","median","min","max"
        ]))

#SYSBP>DIABP check
sysbp=vs[vs["VSTESTCD"]=="SYSBP"][["SUBJID","VISITNUM","VSORRES"]]
diabp=vs[vs["VSTESTCD"]=="DIABP"][["SUBJID","VISITNUM","VSORRES"]]
bp=sysbp.merge(
    diabp,
    on=["SUBJID","VISITNUM"],
    suffixes=("_SYSBP","_DIABP")
    )
bp["SYSBP_GT_DIABP"]=bp["VSORRES_SYSBP"]>bp["VSORRES_DIABP"]
print(bp["SYSBP_GT_DIABP"].value_counts())
print(bp[bp["SYSBP_GT_DIABP"]==False])
print(bp.shape)
print(bp.isnull().sum())

#Baseline BP summarize baseline sysbp diabp
sysbp=vs[vs["VSTESTCD"]=="SYSBP"][["SUBJID","VISITNUM","VSORRES"]]
diabp=vs[vs["VSTESTCD"]=="DIABP"][["SUBJID","VISITNUM","VSORRES"]]
sysbp_baseline=sysbp[sysbp["VISITNUM"]==0]
diabp_baseline=diabp[diabp["VISITNUM"]==0]
print((sysbp_baseline)[["SUBJID","VISITNUM","VSORRES"]])
print((diabp_baseline)[["SUBJID","VISITNUM","VSORRES"]])

#Change in SYSBP 
sysbp_week24=sysbp[sysbp["VISITNUM"]==24][["SUBJID","VISITNUM","VSORRES"]]
print((sysbp_week24)[["SUBJID","VISITNUM","VSORRES"]])
sysbp_change=sysbp_baseline.merge(
    sysbp_week24,on="SUBJID",suffixes=("_BASE","_W24"))
sysbp_change["CHANGE"]=(sysbp_change["VSORRES_W24"]-sysbp_change["VSORRES_BASE"]
                        )
sysbp_change=sysbp_change.merge(
    dm[["SUBJID","ARM"]],
    on="SUBJID"
    )
print(sysbp_change.groupby("ARM")["CHANGE"].agg(
    ["count","mean","median","std","min","max"]
    ))
#Change DIABP baseline
diabp_week24=diabp[diabp["VISITNUM"]==24][["SUBJID","VISITNUM","VSORRES"]]
print((diabp_week24)[["SUBJID","VISITNUM","VSORRES"]])
diabp_change=diabp_baseline.merge(
    diabp_week24,on="SUBJID",suffixes=("_BASE","_W24")
    )
diabp_change["CHANGE"]=(diabp_change["VSORRES_W24"]-diabp_change["VSORRES_BASE"])
diabp_change=diabp_change.merge(
    dm[["SUBJID","ARM"]],on="SUBJID"
    )
print(diabp_change.groupby("ARM")["CHANGE"].agg(
    ["count","max","min","std","mean","median"]
    ))

#Treatment wise BP
print(vs["VSTESTCD"].value_counts())
weight = vs[vs["VSTESTCD"] == "WEIGHT"]
weight_baseline=weight[weight["VISITNUM"]==0]
weight_week24=weight[weight["VISITNUM"]==24]
weight_change=weight_baseline.merge(
    weight_week24,on="SUBJID",suffixes=("_BASE","_W24")
    )
weight_change["CHANGE"]=(weight_change["VSORRES_W24"]-weight_change["VSORRES_BASE"])
weight_change = weight_change.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)
print(weight_change.groupby("ARM")[
    ["VSORRES_BASE", "VSORRES_W24", "CHANGE"]
].agg(["count", "mean", "std", "min", "max"]))

#BP trend by treatment arm 
sysbp_arm_trend = sysbp.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)

sysbp_arm_trend = sysbp_arm_trend.groupby(
    ["ARM", "VISITNUM"]
)["VSORRES"].mean().reset_index()

print(sysbp_arm_trend)
import matplotlib.pyplot as plt
for arm in sysbp_arm_trend["ARM"].unique():
    data = sysbp_arm_trend[sysbp_arm_trend["ARM"] == arm]

    plt.plot(
        data["VISITNUM"],
        data["VSORRES"],
        marker="o",
        label=arm
    )

plt.xlabel("Visit")
plt.ylabel("Mean SYSBP (mmHg)")
plt.title("Mean SYSBP Trend by Treatment Arm")
plt.legend()
plt.show()

diabp_arm_trend = diabp.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)

diabp_arm_trend = diabp_arm_trend.groupby(
    ["ARM", "VISITNUM"]
)["VSORRES"].mean().reset_index()

#Mean BP change by treatment arm
bp_change = pd.DataFrame({
    "ARM": sysbp_change.groupby("ARM")["CHANGE"].mean().index,
    "SYSBP_CHANGE": sysbp_change.groupby("ARM")["CHANGE"].mean().values,
    "DIABP_CHANGE": diabp_change.groupby("ARM")["CHANGE"].mean().values
})

print(bp_change)
bp_change.plot(
    x="ARM",
    y=["SYSBP_CHANGE", "DIABP_CHANGE"],
    kind="bar"
)

plt.xlabel("Treatment Arm")
plt.ylabel("Mean Change from Baseline (mmHg)")
plt.title("Mean BP Change from Baseline by Treatment Arm")
plt.xticks(rotation=0)
plt.show()
