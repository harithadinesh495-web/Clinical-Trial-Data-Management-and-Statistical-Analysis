#T2DM Clinical Trial
#Exposure analysis-EX

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load EX dataset 
ex=pd.read_sql("SELECT* FROM EX", connection)

#Load CM dataset
cm=pd.read_sql("SELECT* FROM CM", connection)

#Load AE dataset
ae=pd.read_sql("SELECT* FROM AE", connection)

#Load VS datset
vs=pd.read_sql("SELECT * FROM VS", connection)

#Load LB dataset
lb=pd.read_sql("SELECT * FROM LB",connection)

#Load DM dataset
dm=pd.read_sql("SELECT* FROM DM",connection)

#Dataset dimensions
print(ex.shape)

#Dataset columns
print(ex.columns)

#Data types
print(ex.dtypes)

#Missing values
print(ex.isnull().sum())

#Duplicate checking 
print(ex.duplicated())
print(ex.duplicated(subset=["SUBJID","EXSEQ"]).sum())

#Frequency distribution
print(ex["EXSEQ"].value_counts())
print(ex["EXTRT"].value_counts())
print(ex["EXDOSE"].value_counts())
print(ex["VISIT"].value_counts())
print(ex["EXDOSU"].value_counts())
print(ex["EXROUTE"].value_counts())
print(ex["EXFREQ"].value_counts())

#Exposure by treatment arm
print(ex.groupby("EXTRT")["EXSEQ"].agg(
    ["mean","count","std"]
    ))

#Treatment-Route/visit
freq_by_arm=pd.crosstab(
    ex["EXTRT"],
    ex["EXROUTE"]
    )
print(freq_by_arm)
visit_by_arm=pd.crosstab(
    ex["EXROUTE"],
    ex["VISIT"]
    )
print(visit_by_arm)

#Exposure dose summary
exdose_summary=ex.groupby("EXTRT")["EXDOSE"].agg(
    ["count","mean","std","median","min","max"]
    )
print(exdose_summary)

#Unique values
print(ex["EXTRT"].unique())
print(ex["EXTRT"].nunique())
print(ex["EXDOSU"].unique())
print(ex["EXDOSU"].nunique())
print(ex["EXROUTE"].unique())
print(ex["EXROUTE"].nunique())
print(ex["VISIT"].unique())
print(ex["VISIT"].nunique())

#Subject level analysis
ex_per_subject=ex.groupby("SUBJID").size()
print(ex_per_subject)

#Date conversion
print(ex["EXSTDTC"].dtypes)
ex["EXSTDTC"]=pd.to_datetime(ex["EXSTDC"])
print(ex["EXSTDTC"].dtypes)

#Exposure frequency 
ex_frequency = ex.groupby("EXTRT").size()
import matplotlib.pyplot as plt
ex_frequency.plot(kind="bar")
plt.xlabel("Treatment Arm")
plt.ylabel("Number of Exposure Records")
plt.title("Exposure Frequency by Treatment Arm")
plt.xticks(rotation=0)
plt.show()

#Dose distribution
ex["EXDOSE"].plot(
    kind="hist",
    bins=20
)
plt.xlabel("Exposure Dose")
plt.ylabel("Frequency")
plt.title("Exposure Dose Distribution")
plt.show()










