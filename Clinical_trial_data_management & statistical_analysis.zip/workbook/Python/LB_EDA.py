#T2DM Clinical Trial
#Laboratory Analysis-LB

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load LB dataset 
lb = pd.read_sql("SELECT * FROM dbo.LB", connection)

#Load DM dataset 

dm = pd.read_sql("SELECT * FROM dbo.DM", connection)

#Dimensions
print(lb.shape)

#Column names
print(lb.columns)

#Data types
print(lb.dtypes)

#Missing values
print(lb.isnull().sum())

#Duplicate logical records
print(lb.duplicated(subset=['SUBJID','LBTESTCD','VISITNUM']).sum())

#Unique subjects
print(lb['SUBJID'].nunique())

#Frequency of each LBTESTCD 
fbg_freq=lb['LBTESTCD'].value_counts(dropna=True)
print(fbg_freq)

#No.of records by visit
visit_freq=lb['VISIT'].value_counts(dropna=True)
print(visit_freq)
print(lb.groupby(['VISITNUM','VISIT']).size())

#Unit distribution 
unit_freq=lb['LBORRESU'].value_counts(dropna=True)
print(unit_freq)
print(lb.groupby(['VISIT','VISITNUM','LBORRESU','LBTESTCD']).size())

#Descriptive statistics for numeric results
print(lb['LBORRES'].describe())

#Descriptive statistics test wise 
print(lb.groupby("LBTESTCD")["LBSTRESN"].agg(
    ["count", "mean", "std", "median", "min", "max"]
))

#Missing laboratory results	in LBORRES / LBSTRESN
print(lb[['LBSTRESN','LBORRES']].isnull().sum())

#HbA1c distribution
HbA1c_d=lb[lb["LBTESTCD"]=="HBA1C"]
print(HbA1c_d.groupby("VISIT")["LBORRES"].agg(
    ["count", "mean", "std", "median", "min", "max"]
    ))

#HbA1c change
hba1c = lb[lb["LBTESTCD"] == "HBA1C"]
hba1c_baseline = hba1c[hba1c["VISITNUM"] == 0]
hba1c_week24 = hba1c[hba1c["VISITNUM"] == 24]
hba1c_change = hba1c_baseline.merge(
    hba1c_week24,
    on="SUBJID",
    suffixes=("_BASE", "_W24")
)
hba1c_change["CHANGE"] = (
    hba1c_change["LBSTRESN_W24"]
    - hba1c_change["LBSTRESN_BASE"]
)
print(hba1c_change[["SUBJID","LBSTRESN_BASE","LBSTRESN_W24","CHANGE"]])
print(hba1c_baseline["LBSTRESN"].describe())

#Treatment wise HbA1c
hba1c_change = hba1c_change.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)
print(hba1c_change.groupby("ARM")["CHANGE"].agg(
    ["count", "mean", "std", "median", "min", "max"]
))

#FBG distribution
fbg=lb[lb["LBTESTCD"]=="FBG"]
print(fbg.groupby("VISIT")["LBORRES"].agg(
    ["count", "mean", "std", "median", "min", "max"]
    ))
print(fbg["LBSTRESN"].describe())

#FBG change
fbg=lb[lb["LBTESTCD"]=="FBG"]
fbg_baseline=fbg[fbg["VISITNUM"]==0]
fbg_week24=fbg[fbg["VISITNUM"]==24]
fbg_change=fbg_baseline.merge(
    fbg_week24,on="SUBJID",
    suffixes=("_BASE","_W24"))
fbg_change["CHANGE"]=(
    fbg_change["LBSTRESN_W24"]-fbg_change["LBSTRESN_BASE"]
    )
fbg_change = fbg_change.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)
print(fbg_change.groupby("ARM")["CHANGE"].agg(
    ["count", "mean", "std", "median", "min", "max"]
))

#Treatment wise descriptive statistics
print(lb.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
).groupby(
    ["LBTESTCD", "ARM"]
)["LBSTRESN"].agg(
    ["count", "mean", "std", "median", "min", "max"]
))

#Baseline laboratory summary 
baseline = lb[lb["VISITNUM"] == 0]
print(baseline.groupby("LBTESTCD")["LBSTRESN"].agg(
    ["count", "mean", "std", "median", "min", "max"]
)
)

#Week24 laboratory summary
week24=lb[lb["VISITNUM"]==24]
print(week24.groupby("LBTESTCD")["LBSTRESN"].agg(
    ["count","mean","std","median","min","max"]))

#HbA1c trend across visits
hba1c = lb[lb["LBTESTCD"] == "HBA1C"]
hba1c_trend = hba1c.groupby("VISITNUM")["LBSTRESN"].mean()
print(hba1c_trend)
import matplotlib.pyplot as plt
plt.plot(hba1c_trend.index, hba1c_trend.values, marker="o")
plt.xlabel("Visit")
plt.ylabel("Mean HbA1c (%)")
plt.title("Mean HbA1c Across Visits")
plt.show()

#FBG distribution
fbg = lb[lb["LBTESTCD"] == "FBG"]
plt.hist(fbg["LBSTRESN"], bins=20)
plt.xlabel("FBG (mg/dL)")
plt.ylabel("Frequency")
plt.title("FBG Distribution")
plt.show()

#Treatment wise FBG change
import seaborn as sns
sns.boxplot(
    data=fbg_change,
    x="ARM",
    y="CHANGE"
)
plt.xlabel("Treatment Arm")
plt.ylabel("FBG Change from Baseline (mg/dL)")
plt.title("FBG Change from Baseline by Treatment")
plt.show()

#min and max fbg value at each visit
print(fbg.groupby("VISIT")["LBSTRESN"].agg(
    ["min","max"]))