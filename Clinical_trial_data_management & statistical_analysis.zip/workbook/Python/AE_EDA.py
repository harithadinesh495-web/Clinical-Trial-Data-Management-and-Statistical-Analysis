#T2DM Clinical Trial
#Adverse Events Analysis-AE

import pandas as pd
import pyodbc

#Connect to SQL server

connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load AE dataset
ae=pd.read_sql("SELECT* FROM AE", connection)

#Load VS datset
vs=pd.read_sql("SELECT * FROM VS", connection)

#Load LB dataset
lb=pd.read_sql("SELECT * FROM LB",connection)

#Load DM dataset
dm=pd.read_sql("SELECT* FROM DM",connection)

#Dataset dimensions
print(ae.shape)

#Column names
print(ae.columns)

#Data types
print(ae.dtypes)

#Missing values
print(ae.isnull().sum())

#Duplicate logical records
print(ae.duplicated(subset=["SUBJID","AESEQ","AETERM"]).sum())

#AE severity 
print(ae["AESEV"].value_counts())

#Count AE terms
print(ae["AETERM"].value_counts())

#Count of severity according to treatment
ae_trt=ae.merge(
    dm[["SUBJID","ARM"]],
    on="SUBJID")
print(ae_trt)
print(ae_trt["ARM"].value_counts())
print(pd.crosstab(ae_trt["AESEV"],ae_trt["ARM"]))

#Uniqueness of adverse event severity
print(ae["AESEV"].nunique())

#Date conversion 
print(ae[["AESTDTC", "AEENDTC"]].dtypes)
ae["AESTDTC"] = pd.to_datetime(ae["AESTDTC"])
ae["AEENDTC"] = pd.to_datetime(ae["AEENDTC"])
print(ae[["AESTDTC", "AEENDTC"]].dtypes)

#Duration calculation 
ae["AE_DURATION"] = ae["AEENDTC"] - ae["AESTDTC"]
print(ae[["SUBJID", "AESTDTC", "AEENDTC", "AE_DURATION"]])

#AE severity distribution
import matplotlib.pyplot as plt
ae_severity = pd.crosstab(
    ae_trt["ARM"],
    ae_trt["AESEV"]
)
ae_severity.plot(kind="bar")
plt.xlabel("Treatment Arm")
plt.ylabel("Number of AE Records")
plt.title("AE Severity Distribution by Treatment Arm")
plt.xticks(rotation=0)
plt.show()
