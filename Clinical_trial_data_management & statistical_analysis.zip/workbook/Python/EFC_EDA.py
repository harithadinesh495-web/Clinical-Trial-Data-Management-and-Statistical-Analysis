#T2DM Clinical Trial
#Efficacy analysis-EFC

import pandas as pd 
import numpy as np
import pyodbc 

#Connect to SQL server
connection = pyodbc.connect(
    "DRIVER={ODBC Driver 18 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"
    "DATABASE=T2_DM_Clinical_Trial;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
print("Connection successful!")

#Load EFC dataset
efc=pd.read_sql("SELECT* FROM EFC", connection)

#Load EX dataset 
ex=pd.read_sql("SELECT* FROM EX", connection)

#Load CM dataset
cm=pd.read_sql("SELECT* FROM CM", connection)

#Load AE dataset
ae=pd.read_sql("SELECT* FROM AE", connection)

#Load VS datset
vs=pd.read_sql("SELECT * FROM VS", connection)

#Load LB dataset
lb=pd.read_sql("SELECT * FROM LB",connection)

#Load DM dataset
dm=pd.read_sql("SELECT* FROM DM",connection)

#Dataset dimensions
print(efc.shape)

#Data types
print(efc.dtypes)
print(efc[["BASE_HBA1C", "W24_HBA1C"]].dtypes)

#Data type conversion
efc["BASE_HBA1C"] = pd.to_numeric(efc["BASE_HBA1C"], errors="coerce")
efc["W24_HBA1C"] = pd.to_numeric(efc["W24_HBA1C"], errors="coerce")

#Missing values
print(efc.isnull().sum())

#Duplicate checking 
print(efc["SUBJID"].duplicated().sum())
print(efc["SUBJID"].nunique())

# Calculate HbA1c change
efc["CHG_HBA1C"] = (
    efc["W24_HBA1C"]
    - efc["BASE_HBA1C"]
)
print(
    efc[
        ["SUBJID", "BASE_HBA1C", "W24_HBA1C", "CHG_HBA1C"]
    ].head()
)

# Add treatment arm from DM
efc = efc.merge(
    dm[["SUBJID", "ARM"]],
    on="SUBJID"
)
print(
    efc[
        ["SUBJID", "ARM", "CHG_HBA1C"]
    ].head()
)

# Treatment-wise HbA1c change
print(
    efc.groupby("ARM")["CHG_HBA1C"].agg(
        ["count", "mean", "std", "median", "min", "max"]
    )
)

# Independently calculate HbA1c change from LB
hba1c = lb[lb["LBTESTCD"] == "HBA1C"]
baseline = hba1c[hba1c["VISITNUM"] == 0]
week24 = hba1c[hba1c["VISITNUM"] == 24]
hba1c_check = baseline.merge(
    week24,
    on="SUBJID",
    suffixes=("_BASE", "_W24")
)
hba1c_check["CHANGE_FROM_LB"] = (
    hba1c_check["LBSTRESN_W24"]
    - hba1c_check["LBSTRESN_BASE"]
)

# Compare EFC change with LB-derived change
efc_check = efc[
    ["SUBJID", "CHG_HBA1C"]
].merge(
    hba1c_check[
        ["SUBJID", "CHANGE_FROM_LB"]
    ],
    on="SUBJID"
)
print(efc_check.head())
print(
    efc_check[
        ~np.isclose(efc_check["CHG_HBA1C"], efc_check["CHANGE_FROM_LB"])
    ]
)

# Visualization
import matplotlib.pyplot as plt
efc.groupby("ARM")["CHG_HBA1C"].mean().plot(
    kind="bar"
)
plt.xlabel("Treatment Arm")
plt.ylabel("Mean Change in HbA1c (%)")
plt.title("Mean HbA1c Change from Baseline to Week 24")
plt.xticks(rotation=0)
plt.show()